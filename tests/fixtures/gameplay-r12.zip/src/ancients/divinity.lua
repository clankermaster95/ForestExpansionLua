FE_Light = { vanguard = {}, nuke = {} }

function FE_Light.vanguardCast(unit)
    local old = FE_Light.vanguard[unit]
    if old then PauseTimer(old.timer); DestroyTimer(old.timer) end
    local level = math.max(1, math.min(4, GetUnitAbilityLevel(unit, FourCC("A06U"))))
    local state = {timer=CreateTimer(), pulses=0, heal=50+50*level}
    FE_Light.vanguard[unit] = state
    FE_Combat.hiddenAbility(unit, "AFVA", level)
    -- Preserve the original immediate first heal and six total healing pulses.
    SetWidgetLife(unit, GetWidgetLife(unit) + state.heal)
    TimerStart(state.timer, 1, true, function()
        state.pulses = state.pulses + 1
        if state.pulses < 6 and FE_Combat.alive(unit) then SetWidgetLife(unit, GetWidgetLife(unit) + state.heal) end
        if state.pulses >= 6 or not FE_Combat.alive(unit) then
            if FE_Light.vanguard[unit] == state then
                FE_Light.vanguard[unit] = nil
                FE_Combat.hiddenAbility(unit, "AFVA", 0)
            end
            PauseTimer(state.timer); DestroyTimer(state.timer)
        end
    end)
end

function FE_Light.nukeCast(unit)
    local old = FE_Light.nuke[unit]
    if old then PauseTimer(old.timer); DestroyTimer(old.timer) end
    local level = math.max(1, math.min(3, GetUnitAbilityLevel(unit, FourCC("A06W"))))
    local state = {timer=CreateTimer(), ticks=0, damage=(50+50*level)*0.25}
    FE_Light.nuke[unit] = state
    -- Native Bladestorm retains its immunity/animation, but targets no units.
    -- Its AoE damage is applied separately, so normal attacks keep working.
    TimerStart(state.timer, 0.25, true, function()
        state.ticks = state.ticks + 1
        if FE_Combat.alive(unit) then
            FE_Combat.near(unit, 250, function(target)
                if IsUnitEnemy(target, GetOwningPlayer(unit)) then
                    FE_Combat.damage(unit, target, state.damage, DAMAGE_TYPE_ENHANCED)
                end
            end)
        end
        if state.ticks >= 20 or not FE_Combat.alive(unit) then
            if FE_Light.nuke[unit] == state then FE_Light.nuke[unit] = nil end
            PauseTimer(state.timer); DestroyTimer(state.timer)
        end
    end)
end


-- ancients / divinity
-- Related gameplay callbacks; original initialization order is in src/initialization.lua.

-- BEGIN FOREST SECTION 179 Sadism
function Trig_Sadism_Conditions()
    return GetSpellAbilityId() == FourCC("A075")
end

function Trig_Sadism_Actions()
    FE_Ice.start(GetSpellAbilityUnit())
end

function InitTrig_Sadism()
    FE_Ice.init()
    gg_trg_Sadism = CreateTrigger()
    TriggerRegisterAnyUnitEventBJ(gg_trg_Sadism, EVENT_PLAYER_UNIT_SPELL_EFFECT)
    TriggerAddCondition(gg_trg_Sadism, Condition(Trig_Sadism_Conditions))
    TriggerAddAction(gg_trg_Sadism, Trig_Sadism_Actions)
end
-- END FOREST SECTION 179

-- BEGIN FOREST SECTION 180 Reckoning
function Trig_Reckoning_Conditions()
    return GetSpellAbilityId() == FourCC("A06W")
end

function Trig_Reckoning_Actions()
    FE_Light.nukeCast(GetSpellAbilityUnit())
    udg_TSEDuration = __jreal(5.00)
    udg_TSEScale = __jreal(0.45)
    udg_TSEAttachPoint = "origin"
    udg_TSEEffectName = "war3mapImported\\HolyTornado.mdx"
    udg_TSETargetUnit = GetSpellAbilityUnit()
    ConditionalTriggerExecute(udg_TSE_RegisterTrigger)
end

function InitTrig_Reckoning()
    gg_trg_Reckoning = CreateTrigger()
    TriggerRegisterAnyUnitEventBJ(gg_trg_Reckoning, EVENT_PLAYER_UNIT_SPELL_EFFECT)
    TriggerAddCondition(gg_trg_Reckoning, Condition(Trig_Reckoning_Conditions))
    TriggerAddAction(gg_trg_Reckoning, Trig_Reckoning_Actions)
end
-- END FOREST SECTION 180

-- BEGIN FOREST SECTION 181 Vanguard_Initial
function Trig_Vanguard_Initial_Conditions()
    return GetLearnedSkillBJ() == FourCC("A06U")
end

function Trig_Vanguard_Initial_Actions()
    udg_VanguardHeal = (__jreal(udg_VanguardHeal + __jreal(100.00)))
    TriggerSleepAction(__jreal(5.00))
    EnableTrigger(gg_trg_Vanguard_Future_Levels)
    DisableTrigger(GetTriggeringTrigger())
end

function InitTrig_Vanguard_Initial()
    gg_trg_Vanguard_Initial = CreateTrigger()
    TriggerRegisterAnyUnitEventBJ(gg_trg_Vanguard_Initial, EVENT_PLAYER_HERO_SKILL)
    TriggerAddCondition(gg_trg_Vanguard_Initial, Condition(Trig_Vanguard_Initial_Conditions))
    TriggerAddAction(gg_trg_Vanguard_Initial, Trig_Vanguard_Initial_Actions)
end
-- END FOREST SECTION 181

-- BEGIN FOREST SECTION 182 Vanguard_Future_Levels
function Trig_Vanguard_Future_Levels_Conditions()
    return GetLearnedSkillBJ() == FourCC("A06U")
end

function Trig_Vanguard_Future_Levels_Actions()
    udg_VanguardHeal = (__jreal(udg_VanguardHeal + __jreal(50.00)))
end

function InitTrig_Vanguard_Future_Levels()
    gg_trg_Vanguard_Future_Levels = CreateTrigger()
    DisableTrigger(gg_trg_Vanguard_Future_Levels)
    TriggerRegisterAnyUnitEventBJ(gg_trg_Vanguard_Future_Levels, EVENT_PLAYER_HERO_SKILL)
    TriggerAddCondition(gg_trg_Vanguard_Future_Levels, Condition(Trig_Vanguard_Future_Levels_Conditions))
    TriggerAddAction(gg_trg_Vanguard_Future_Levels, Trig_Vanguard_Future_Levels_Actions)
end
-- END FOREST SECTION 182

-- BEGIN FOREST SECTION 183 Vanguard
function Trig_Vanguard_Conditions()
    return GetSpellAbilityId() == FourCC("A06U")
end

function Trig_Vanguard_Actions()
    FE_Light.vanguardCast(GetSpellAbilityUnit())
end

function InitTrig_Vanguard()
    gg_trg_Vanguard = CreateTrigger()
    TriggerRegisterAnyUnitEventBJ(gg_trg_Vanguard, EVENT_PLAYER_UNIT_SPELL_EFFECT)
    TriggerAddCondition(gg_trg_Vanguard, Condition(Trig_Vanguard_Conditions))
    TriggerAddAction(gg_trg_Vanguard, Trig_Vanguard_Actions)
end
-- END FOREST SECTION 183

-- BEGIN FOREST SECTION 184 Omniscience_Initial
function Trig_Omniscience_Initial_Conditions()
    return GetLearnedSkillBJ() == FourCC("A06X")
end

function Trig_Omniscience_Initial_Actions()
    udg_Div = GetLearningUnit()
    udg_Omni = 1
    EnableTrigger(gg_trg_Omniscience)
    EnableTrigger(gg_trg_Omniscience_FL)
    DisableTrigger(GetTriggeringTrigger())
end

function InitTrig_Omniscience_Initial()
    gg_trg_Omniscience_Initial = CreateTrigger()
    TriggerRegisterAnyUnitEventBJ(gg_trg_Omniscience_Initial, EVENT_PLAYER_HERO_SKILL)
    TriggerAddCondition(gg_trg_Omniscience_Initial, Condition(Trig_Omniscience_Initial_Conditions))
    TriggerAddAction(gg_trg_Omniscience_Initial, Trig_Omniscience_Initial_Actions)
end
-- END FOREST SECTION 184

-- BEGIN FOREST SECTION 185 Omniscience_FL
function Trig_Omniscience_FL_Conditions()
    return GetLearnedSkillBJ() == FourCC("A06X")
end

function Trig_Omniscience_FL_Actions()
    udg_Omni = (__jint(udg_Omni + 1))
end

function InitTrig_Omniscience_FL()
    gg_trg_Omniscience_FL = CreateTrigger()
    DisableTrigger(gg_trg_Omniscience_FL)
    TriggerRegisterAnyUnitEventBJ(gg_trg_Omniscience_FL, EVENT_PLAYER_HERO_SKILL)
    TriggerAddCondition(gg_trg_Omniscience_FL, Condition(Trig_Omniscience_FL_Conditions))
    TriggerAddAction(gg_trg_Omniscience_FL, Trig_Omniscience_FL_Actions)
end
-- END FOREST SECTION 185

-- BEGIN FOREST SECTION 186 Omniscience
function Trig_Omniscience_Actions()
    AddHeroXPSwapped(udg_Omni, udg_Div, true)
end

function InitTrig_Omniscience()
    gg_trg_Omniscience = CreateTrigger()
    DisableTrigger(gg_trg_Omniscience)
    TriggerRegisterTimerEventPeriodic(gg_trg_Omniscience, __jreal(1.00))
    TriggerAddAction(gg_trg_Omniscience, Trig_Omniscience_Actions)
end
-- END FOREST SECTION 186

-- BEGIN FOREST SECTION 187 Redemption
function Trig_Redemption_Conditions()
    return GetSpellAbilityId() == FourCC("A06Y")
end

function Trig_Redemption_Actions()
    SetUnitLifePercentBJ(GetSpellAbilityUnit(), __jreal(100))
    SetUnitManaPercentBJ(GetSpellAbilityUnit(), __jreal(100))
end

function InitTrig_Redemption()
    gg_trg_Redemption = CreateTrigger()
    TriggerRegisterAnyUnitEventBJ(gg_trg_Redemption, EVENT_PLAYER_UNIT_SPELL_EFFECT)
    TriggerAddCondition(gg_trg_Redemption, Condition(Trig_Redemption_Conditions))
    TriggerAddAction(gg_trg_Redemption, Trig_Redemption_Actions)
end
-- END FOREST SECTION 187
