Forest Expansion 3.2.0 Lua r14

Copy Forest_Expansion_3.2.0_Lua.w3x to your Warcraft III Maps folder.
Start a fresh match; replacing a map does not update an ongoing match.
Shop debug messages are off by default.

CHANGELOG.md describes the release. SOLO_TESTING.md lists testing commands.
This is a test build; live multiplayer validation is still needed.
